# DM Planner - Phase 1

Full-stack DM Planner app.

## Setup
- Backend: `cd server && npm install && npm run dev`
- Frontend: `cd client && npm install && npm start`
