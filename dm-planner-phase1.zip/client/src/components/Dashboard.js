export default function Dashboard({ user }) {
  return (
    <div className="max-w-lg mx-auto bg-white rounded p-6 shadow">
      <h2 className="text-2xl font-bold mb-4">Welcome, {user.username}!</h2>
      {user.role === "DM" ? (
        <div>
          <p className="mb-2">DM Tools:</p>
          <ul className="list-disc pl-6">
            <li>Manage Sessions</li>
            <li>View Players</li>
            <li>Campaign Notes</li>
          </ul>
        </div>
      ) : (
        <div>
          <p className="mb-2">Player Area:</p>
          <ul className="list-disc pl-6">
            <li>My Character</li>
            <li>Spell Book</li>
            <li>Inventory</li>
          </ul>
        </div>
      )}
    </div>
  );
}