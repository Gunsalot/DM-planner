import React, { useState } from "react";
import api from "../services/api";

export default function Login({ setUser }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("Player");
  const [isRegister, setIsRegister] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (isRegister) {
        await api.post("/auth/register", { username, password, role });
        alert("✅ Registered successfully! Please log in.");
        setIsRegister(false);
      } else {
        const res = await api.post("/auth/login", { username, password });
        localStorage.setItem("token", res.data.token);
        setUser({ username: res.data.username, role: res.data.role });
      }
    } catch (err) {
      alert(err.response?.data?.error || "Something went wrong");
    }
  };

  return (
    <div className="max-w-md mx-auto bg-white rounded p-6 shadow">
      <h2 className="text-xl font-bold mb-4">{isRegister ? "Register" : "Login"}</h2>
      <form onSubmit={handleSubmit}>
        <input className="border p-2 w-full mb-2" placeholder="Username" onChange={(e) => setUsername(e.target.value)} />
        <input className="border p-2 w-full mb-2" type="password" placeholder="Password" onChange={(e) => setPassword(e.target.value)} />
        {isRegister && (
          <select className="border p-2 w-full mb-2" onChange={(e) => setRole(e.target.value)}>
            <option value="Player">Player</option>
            <option value="DM">DM</option>
          </select>
        )}
        <button className="bg-green-600 text-white px-4 py-2 rounded w-full">
          {isRegister ? "Register" : "Login"}
        </button>
      </form>
      <button className="mt-2 text-blue-600 underline" onClick={() => setIsRegister(!isRegister)}>
        {isRegister ? "Already have an account? Login" : "No account? Register"}
      </button>
    </div>
  );
}